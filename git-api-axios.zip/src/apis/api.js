export default {
    repo_list: '/user/repos'
}